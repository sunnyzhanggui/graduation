<center>
	<?php include("head.html");
	?>
</center>
<div style="position:absolute;left:30%;top:30%;">
	注册
	<form action="/action/action.php?action=register" method="post">
		<td>用户名:</td><td><input type="text" name="username"/></td><br>
		<td>密码:   </td><td><input type="password" name="password"/></td><br>
		<tr><td></td><td><input type="submit" value="注册"/></td></tr>
	</form>
</div>	